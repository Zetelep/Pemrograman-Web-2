<?php

namespace App\Controllers;

use App\Models\BookModel;
use CodeIgniter\Controller;

class BookController extends Controller
{
    public function index()
    {
        $model = new BookModel();
        $data['books'] = $model->findAll();
        echo view('book_list', $data);
    }

    public function create()
    {
        helper(['form']);
        $data = [];

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'judul'         => 'required|min_length[3]|max_length[255]',
                'penulis'       => 'required|min_length[3]|max_length[255]',
                'penerbit'      => 'required|min_length[3]|max_length[255]',
                'tahun_terbit'  => 'required|numeric|min_length[4]|max_length[4]',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $model = new BookModel();

                $newData = [
                    'judul'         => $this->request->getPost('judul'),
                    'penulis'       => $this->request->getPost('penulis'),
                    'penerbit'      => $this->request->getPost('penerbit'),
                    'tahun_terbit'  => $this->request->getPost('tahun_terbit'),
                ];
                $model->save($newData);
                return redirect()->to('/books');
            }
        }

        echo view('book_form', $data);
    }

    public function edit($id)
    {
        helper(['form']);
        $model = new BookModel();
        $data['book'] = $model->find($id);

        if ($this->request->getMethod() == 'post') {
            $rules = [
                'judul'         => 'required|min_length[3]|max_length[255]',
                'penulis'       => 'required|min_length[3]|max_length[255]',
                'penerbit'      => 'required|min_length[3]|max_length[255]',
                'tahun_terbit'  => 'required|numeric|min_length[4]|max_length[4]',
            ];

            if (!$this->validate($rules)) {
                $data['validation'] = $this->validator;
            } else {
                $newData = [
                    'id'            => $id,
                    'judul'         => $this->request->getPost('judul'),
                    'penulis'       => $this->request->getPost('penulis'),
                    'penerbit'      => $this->request->getPost('penerbit'),
                    'tahun_terbit'  => $this->request->getPost('tahun_terbit'),
                ];
                $model->save($newData);
                return redirect()->to('/books');
            }
        }

        echo view('book_form', $data);
    }

    public function delete($id)
    {
        $model = new BookModel();
        $model->delete($id);
        return redirect()->to('/books');
    }
}
