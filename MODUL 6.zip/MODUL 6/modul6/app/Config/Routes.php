<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// app/Config/Routes.php

// User routes
$routes->get('/', 'AuthController::login');
$routes->match(['get', 'post'], 'register', 'AuthController::register');
$routes->match(['get', 'post'], 'login', 'AuthController::login');
$routes->get('logout', 'AuthController::logout');

$routes->get('books', 'BookController::index');
$routes->match(['get', 'post'], 'books/create', 'BookController::create');
$routes->match(['get', 'post'], 'books/edit/(:num)', 'BookController::edit/$1');
$routes->get('books/delete/(:num)', 'BookController::delete/$1');


