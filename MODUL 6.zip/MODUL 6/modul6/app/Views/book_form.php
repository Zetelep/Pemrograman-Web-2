<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= isset($book) ? 'Edit Book' : 'Add Book' ?></title>
</head>
<body>
    <h1><?= isset($book) ? 'Edit Book' : 'Add Book' ?></h1>
    <form action="<?= isset($book) ? '/books/edit/'.$book['id'] : '/books/create' ?>" method="post">
        <label for="judul">Judul</label>
        <input type="text" name="judul" id="judul" value="<?= isset($book) ? $book['judul'] : '' ?>">
        <br>
        <label for="penulis">Penulis</label>
        <input type="text" name="penulis" id="penulis" value="<?= isset($book) ? $book['penulis'] : '' ?>">
        <br>
        <label for="penerbit">Penerbit</label>
        <input type="text" name="penerbit" id="penerbit" value="<?= isset($book) ? $book['penerbit'] : '' ?>">
        <br>
        <label for="tahun_terbit">Tahun Terbit</label>
        <input type="text" name="tahun_terbit" id="tahun_terbit" value="<?= isset($book) ? $book['tahun_terbit'] : '' ?>">
        <br>
        <input type="submit" value="<?= isset($book) ? 'Update' : 'Save' ?>">
    </form>
    <?= \Config\Services::validation()->listErrors(); ?>
</body>
</html>
