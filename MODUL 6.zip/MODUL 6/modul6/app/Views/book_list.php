<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Book List</title>
</head>
<body>
    <h1>Book List</h1>
    <a href="/books/create">Add Book</a>
    <table>
        <thead>
            <tr>
                <th>Judul</th>
                <th>Penulis</th>
                <th>Penerbit</th>
                <th>Tahun Terbit</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($books as $book): ?>
                <tr>
                    <td><?= $book['judul'] ?></td>
                    <td><?= $book['penulis'] ?></td>
                    <td><?= $book['penerbit'] ?></td>
                    <td><?= $book['tahun_terbit'] ?></td>
                    <td>
                        <a href="/books/edit/<?= $book['id'] ?>">Edit</a>
                        <a href="/books/delete/<?= $book['id'] ?>">Delete</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
